# Curated content provenance

Verified 2026-10-19. The collection now includes 15 source-referenced entries. Each item carries a source, reference, and rights note in the library. No third-party modern English translations are bundled.

## Quran
Verbatim Arabic verses from the official Tanzil Uthmani text download:
https://tanzil.net/pub/download/index.php?quranType=uthmani&outType=txt&agree=true

The unmodified download is retained in `research/tanzil-uthmani.txt`. The selected complete verses are 1:1, 2:152, 2:186, 2:201, 3:8, 13:28, 14:7 and 20:114; the latter is indexed after the seven Al-Fatihah verses. Attribution and the entire embedded notice are retained in `assets/content/TANZIL-LICENSE.txt`. Source: Tanzil Project, https://tanzil.net, Copyright 2007–2021, Creative Commons Attribution 3.0, with the additional verbatim-copy/no-changes terms at https://tanzil.net/docs/text_license. Quran labels are references, not translations.

## Classical hadith and supplication
Short public-domain classical Arabic excerpts were transcribed and verified against the following references. We do not bundle a scraped database or reproduce copyrighted modern translations. English labels describe the subject rather than translating a publisher's wording.

- Hadith on intention: Sahih al-Bukhari 1, https://sunnah.com/bukhari:1. The displayed text is explicitly marked as an excerpt, not a complete narration. Authenticity: included in Sahih al-Bukhari.
- Bedtime supplication: Sahih al-Bukhari 6312, https://sunnah.com/bukhari:6312. The exact wording selected is `بِاسْمِكَ أَمُوتُ وَأَحْيَا`; no extra words are inserted. Authenticity: included in Sahih al-Bukhari.
- Helping someone in need: practical Sunnah reminder, original Arabic and English paraphrase based on Sahih al-Bukhari 6028, https://sunnah.com/bukhari:6028. The reminder is identified as an authored paraphrase, not a quotation or translation of the narration.

The common starter Dhikr phrases are traditional invocations, with project-authored English meanings; no specific count/reward claims are attached.


## Added 2026-10-21

The selected verses are copied without changing a character from the retained Tanzil Uthmani download. An automated test compares every included verse against that source.

- Supplication for forgiveness, mercy, guidance and provision: Sahih Muslim 2697a, https://sunnah.com/muslim:2697a.
- Supplication for guidance, piety, chastity and sufficiency: Sahih Muslim 2721a, https://sunnah.com/muslim:2721a.
- Two expressions of remembrance: the prophetic wording in Sahih al-Bukhari 6406, https://sunnah.com/bukhari:6406; the chain of narrators is omitted.
- Good speech: a labeled short excerpt from Sahih al-Bukhari 6018, https://sunnah.com/bukhari:6018.

English topic labels are original descriptions, not publisher translations. The suggestion cards open a full-text/source dialog and allow cycling through each category.

## Expanded curated collection (1.4.0)

20 countable adhkar, including salawat, hawqala, the four words, full tahlil and common praise/repentance phrases. The reference is shown beneath new built-in phrases. 259 content entries: 137 Quran verses, 91 duas, 20 hadith excerpts and 11 practical Sunnah reminders. This is a curated collection, not an assertion that every Islamic text or supplication is included.

Quran and Quranic dua entries are complete verses copied unchanged from the retained Tanzil Uthmani corpus. The generator is `tools/expand_library.py`; tests compare every linked Tanzil entry to the full 114-surah verse index. Source: https://tanzil.net/docs/text_license. Topic labels are original metadata, not translations.

Quranic supplication topics cover Adam, Nuh, Ibrahim/Ismail, Lut, Shuayb, Musa, Yusuf, Ayyub, Yunus, Zakariyya, Sulayman and Isa, plus general Quranic supplications. Surrounding verse context is retained; the app does not invent a supplication for prophets without a quoted prayer. Entries can be found by Arabic/English prophet/topic names and verse references.

Added classical Arabic hadith excerpts reference Sahih al-Bukhari 10, 13, 69, 799, 3370, 5027, 5376, 6011, 6018, 6024, 6116, 6306, 6307, 6369, 6384, 6405, 6406, 6412 and Sahih Muslim 54a, 55a, 91a, 223, 408, 2564c, 2588, 2593, 2626, 2691, 2695, 2699a, 2708a, 2725a, 2726a, as applicable to the category. References and excerpts were checked against public Sunnah.com pages. No modern hadith translation was copied; topic labels are original. Practical Sunnah cards explicitly label their wording as an authored reminder based on the linked narration.
