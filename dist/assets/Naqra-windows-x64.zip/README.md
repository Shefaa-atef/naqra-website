# Naqra · نقرة

Local-first Flutter Windows companion for Dhikr, with a global counter shortcut, temporary shortcut feedback, configurable reminders, offline prayer calculations, and Arabic/English interface.

## Run and build

Requires Flutter 3.41 / Dart 3.11 or compatible, Windows 10/11 x64, Visual Studio 2022 Desktop development with C++, Windows SDK, and CMake.

```powershell
flutter pub get
flutter gen-l10n
flutter analyze
flutter test
flutter build windows --release
```

Run the executable together with **all** accompanying DLLs and the `data` directory. Copying only `naqra.exe` will not work.

This workstation has usable MSVC/SDK files but no registered installation in `vswhere`, so the standard Flutter Windows command fails. A verified alternative uses the existing files:

```powershell
flutter assemble --output=build '-dTargetPlatform=windows-x64' '-dBuildMode=release' '-dTargetFile=lib/main.dart' release_bundle_windows-x64_assets
.\scripts\configure-existing-toolchain.cmd
.\scripts\build-existing-toolchain.cmd
```

The scripts currently name this machine's Visual Studio Community path. Adjust that path for another workstation. Output: `build/windows/ninja/runner/naqra.exe`. Standard Flutter builds should be preferred on a normally registered toolchain. Neither method requires modifying the Flutter SDK.

## Use

- Select a single Dhikr in Library. The default **F8** shortcut increments that phrase from any application while Naqra is running.
- Settings accepts single function keys or combinations such as `Ctrl+Shift+D` or `Alt+D`. Conflicting/reserved keys are rejected and the previous working binding stays active. F12 is reserved by Windows debugging facilities.
- Counts are independent for each phrase and daily date. Set explicit goals in Daily wird; Home shows the combined daily intention and offers inline dhikr selection. Unplanned dhikr uses free counting.
- Close always hides the main window to the system tray, keeping floating widgets and enabled reminders running. Use **Exit Naqra** to terminate the process. Reminders do not continue after exit or while the computer is asleep.
- F8 or the chosen shortcut saves one count and briefly shows a +1 side card for 1.6 seconds. Repeated presses refresh its timer. The home switch and tray menu enable or disable this feedback; no counter stays on screen after launch.
- Scheduled dhikr, Quran, hadith and duaa appear as timed side text cards. Their configured durations control dismissal. The separate prayer countdown remains optional.
- The tray opens the main app, toggles shortcut feedback, previews +1, and exits.
- Reminders begin only after onboarding consent. Configure each category, active hours, weekdays, interval or daily time, sound, duration, quiet hours, pause, and snooze.
- Prayer calculations require latitude, longitude, IANA timezone, method, and Asr school. Commit text fields with Enter. Per-prayer enable, advance, at-time, duration, sound, and adjustment controls are independent. Verify against local official timetables.
- Arabic/English, light/dark/system, Eastern Arabic numerals, text size, reduced motion, and opaque surfaces are persisted.

## Privacy and storage

No mandatory account, analytics or advertising is implemented. Optional location setup may use Windows location services or network lookup; manual coordinates are supported and prayer times are calculated locally. SQLite data lives in the platform application-support directory returned by `path_provider`. Counts use WAL and synchronous FULL; writes are serialized. Export writes a timestamped JSON file alongside the database and shows its path. Data deletion requires confirmation. The optional startup preference writes the user's Windows startup registration.

`naqra.exe --acceptance` uses an isolated `acceptance-data` directory beside that executable and a separate instance mutex. It is a development/acceptance profile. It does not modify normal-profile counts; global shortcuts may conflict if both profiles are running. Do not distribute acceptance data in a release package.

## Architecture

- `core/models.dart`: preferences, reminder/prayer rules, phrase models and time-range logic.
- `services/repository.dart`: SQLite persistence and delivery deduplication.
- `features/dhikr/counter_controller.dart`: queued counter and phrase operations.
- `services/desktop_service.dart`: native shortcut channel, tray, startup, window lifecycle and synchronization.
- `features/widget/companion_window.dart`: independent Flutter engines for widget/notification windows.
- `features/reminders/reminder_engine.dart`: central in-process scheduler; no service after process exit.
- `features/prayers/prayer_service.dart`: Adhan astronomy and IANA timezone/DST conversion.
- `features/library/content_library.dart`: small attributed local library; provenance in `docs/CONTENT_SOURCES.md`.
- `design_system/`: brand colors, type, component themes and clipped glass/opaque material.
- `localization/arb/`: official Flutter generated navigation strings; `Strings` contains bilingual feature copy.
- `windows/runner/`: single-instance mutex and transactional Win32 `RegisterHotKey` bridge using `MOD_NOREPEAT`; no keyboard hook and no unrelated key capture.

## Verification and remaining acceptance work

See `TASKS.md` for current results and outstanding work. A successful build is not evidence of all native acceptance criteria. Native behavior, multi-monitor/DPI, accessibility, visual review, and installation must be recorded separately. Full acceptance is not claimed until recorded there.

Packaging uses the official portable WiX 3.14.1 binaries in `tools/wix` (downloaded from the WiX project release, without installing machine software). After a release build, run `scripts/package.ps1`. It creates an x64 MSI and portable ZIP in `dist`, excludes acceptance-profile databases, includes content/font notices, and runs MSI validation. The MSI installs under Program Files and therefore requests administrator approval when installed. Packages are unsigned; production distribution needs the publisher's signing certificate. A clean Windows installation also requires the Microsoft Visual C++ x64 runtime: https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist.

Fonts: Manrope, Readex Pro, Amiri, bundled under SIL Open Font License notices in `assets/fonts`. Approved logo supplied by the project owner. Religious text provenance and applicable attribution are documented in `docs/CONTENT_SOURCES.md` and `assets/content/TANZIL-LICENSE.txt`.

Shortcut counts always belong to the dhikr selected on Home. Side reminders never change that selection or take over its shortcut. The +1 card uses the upper-left of the app's display; reminder text uses the lower-right so they do not cover each other. Replacement notifications invalidate old dismissal timers.
